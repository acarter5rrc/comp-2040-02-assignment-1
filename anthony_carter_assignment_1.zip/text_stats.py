# open the input file (named input.txt)
# read it into a variable

# process (parse) (clean it!) (get it ready for .... ???)
# remove punctuation and extra whitespace \n \t \s
# normalization (lowercase the text)
# make it so we can compare our data
# tokenization (split the input string into it's component parts)
# .split() \ - (returns a list of strings)

# calculate/accumulate statistics
# setup variables/data structures for our data
# len() will give us the word count and character
# set() - will give unique word count
# average word count
# 

# output the stats to the terminal and a file (output.txt)
# (in the prescribed format)

"""
Word count: <int>
Unique words: <int>
Characters (with spaces): <int>
Characters (no spaces): <int>
Average word length: <float with 1 decimal>
Most common word(s): <words or blank> (<int>)
"""
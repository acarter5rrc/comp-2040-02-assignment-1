# comp-2040-02-assignment-1
# Hello, I failed to do the tasks of the project.
# However, you can still run reading_text_programs.py file
# I only made 1 output.txt file because I couldn't the correct output for #1